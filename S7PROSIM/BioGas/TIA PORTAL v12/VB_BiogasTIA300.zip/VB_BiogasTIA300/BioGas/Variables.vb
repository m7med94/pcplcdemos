﻿Module Variables
    Public pDataAna(1) As Short
    Public pDataShort As Short
    Public pDataCons(1) As Byte 'Uitgangen
    Public pDataI As Integer
    Public pDataFlValue As Integer
    'Public pDataFlValue(3) As Byte
    Public bytes() As Byte
    Public SimKlock As Boolean
    Public Sw(100) As Byte
    Public pDataRun As Byte
    Public simT As Boolean

End Module
