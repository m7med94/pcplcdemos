﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.TimerGUI = New System.Windows.Forms.Timer(Me.components)
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label59 = New System.Windows.Forms.Label()
        Me.Position = New System.Windows.Forms.TrackBar()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Temperature = New System.Windows.Forms.TrackBar()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Pressure = New System.Windows.Forms.TrackBar()
        Me.LabelValue = New System.Windows.Forms.Label()
        Me.Bsch1_R = New System.Windows.Forms.Label()
        Me.Bsch1_C = New System.Windows.Forms.Label()
        Me.Bsch1_L = New System.Windows.Forms.Label()
        Me.Label263 = New System.Windows.Forms.Label()
        Me.FlareInOperation = New System.Windows.Forms.CheckBox()
        Me.ReleaseFlare = New System.Windows.Forms.CheckBox()
        Me.BCUFault = New System.Windows.Forms.CheckBox()
        Me.ESD_LCP = New System.Windows.Forms.CheckBox()
        Me.ESD_CUST = New System.Windows.Forms.CheckBox()
        Me.ButtonResetLCP = New System.Windows.Forms.Button()
        Me.ButtonReset = New System.Windows.Forms.Button()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.RangeMin = New System.Windows.Forms.NumericUpDown()
        Me.RangeMax = New System.Windows.Forms.NumericUpDown()
        Me.CBRange = New System.Windows.Forms.CheckBox()
        Me.LabelPR = New System.Windows.Forms.Label()
        Me.LabelTemp = New System.Windows.Forms.Label()
        Me.LabelPos = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.LabelFlow = New System.Windows.Forms.Label()
        Me.LabelAutoManual = New System.Windows.Forms.Label()
        Me.CheckBoxSimTemp = New System.Windows.Forms.CheckBox()
        Me.LabelPID = New System.Windows.Forms.Label()
        Me.NumericUpDownSimT = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDownSimPos = New System.Windows.Forms.NumericUpDown()
        Me.CheckBoxSimPos = New System.Windows.Forms.CheckBox()
        Me.StartUpPressure = New System.Windows.Forms.CheckBox()
        Me.LedCH1 = New System.Windows.Forms.Panel()
        Me.LedCH2 = New System.Windows.Forms.Panel()
        Me.LedCH3 = New System.Windows.Forms.Panel()
        Me.LedCH4 = New System.Windows.Forms.Panel()
        Me.LedCH5 = New System.Windows.Forms.Panel()
        Me.LabelCH5 = New System.Windows.Forms.Label()
        Me.LabelCH4 = New System.Windows.Forms.Label()
        Me.LabelCH3 = New System.Windows.Forms.Label()
        Me.LabelCH2 = New System.Windows.Forms.Label()
        Me.LabelCH1 = New System.Windows.Forms.Label()
        Me.LabelSPPos = New System.Windows.Forms.Label()
        Me.LabelChan1 = New System.Windows.Forms.Label()
        Me.LabelChan2 = New System.Windows.Forms.Label()
        Me.LabelChan3 = New System.Windows.Forms.Label()
        Me.LabelChan4 = New System.Windows.Forms.Label()
        Me.LabelChan5 = New System.Windows.Forms.Label()
        Me.LabelSPtem = New System.Windows.Forms.Label()
        Me.CheckBoxSimOn = New System.Windows.Forms.CheckBox()
        Me.Flare1 = New System.Windows.Forms.PictureBox()
        Me.Valve_Stage1_OFF = New System.Windows.Forms.PictureBox()
        Me.Valve_Stage1_ON = New System.Windows.Forms.PictureBox()
        Me.ControlFlapClose_OFF = New System.Windows.Forms.PictureBox()
        Me.ControlFlapClose_ON = New System.Windows.Forms.PictureBox()
        Me.ControlFlapOpen_OFF = New System.Windows.Forms.PictureBox()
        Me.ControlFlapOpen_ON = New System.Windows.Forms.PictureBox()
        Me.Valve_Stage3_OFF = New System.Windows.Forms.PictureBox()
        Me.Valve_Stage3_ON = New System.Windows.Forms.PictureBox()
        Me.Valve_Stage2_OFF = New System.Windows.Forms.PictureBox()
        Me.Valve_Stage2_ON = New System.Windows.Forms.PictureBox()
        Me.Led_HighFlareTemp_OFF = New System.Windows.Forms.PictureBox()
        Me.Led_HighFlareTemp_ON = New System.Windows.Forms.PictureBox()
        Me.Led_LowNozPres_OFF = New System.Windows.Forms.PictureBox()
        Me.Led_LowNozPres_ON = New System.Windows.Forms.PictureBox()
        Me.Led_HighNozPres_OFF = New System.Windows.Forms.PictureBox()
        Me.Led_HighNozPres_ON = New System.Windows.Forms.PictureBox()
        Me.Led_Horn_OFF = New System.Windows.Forms.PictureBox()
        Me.Led_Horn_ON = New System.Windows.Forms.PictureBox()
        Me.Led_FlareINOper_OFF = New System.Windows.Forms.PictureBox()
        Me.Led_FlareInOper_ON = New System.Windows.Forms.PictureBox()
        Me.Led_CommonAlarm_OFF = New System.Windows.Forms.PictureBox()
        Me.Led_CommonAlarm_ON = New System.Windows.Forms.PictureBox()
        Me.Led_ReleaseFlare_OFF = New System.Windows.Forms.PictureBox()
        Me.Led_ReleaseFlare_ON = New System.Windows.Forms.PictureBox()
        Me.Led_ESD_OFF = New System.Windows.Forms.PictureBox()
        Me.Led_ESD_ON = New System.Windows.Forms.PictureBox()
        Me.Led_BCU_OFF = New System.Windows.Forms.PictureBox()
        Me.Led_BCU_ON = New System.Windows.Forms.PictureBox()
        Me.sch1_R = New System.Windows.Forms.PictureBox()
        Me.sch1_C = New System.Windows.Forms.PictureBox()
        Me.sch1_L = New System.Windows.Forms.PictureBox()
        Me.PID = New System.Windows.Forms.PictureBox()
        Me.Flare2 = New System.Windows.Forms.PictureBox()
        Me.Flare3 = New System.Windows.Forms.PictureBox()
        Me.Label21 = New System.Windows.Forms.Label()
        CType(Me.Position, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Temperature, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Pressure, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.RangeMin, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.RangeMax, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDownSimT, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDownSimPos, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Flare1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Valve_Stage1_OFF, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Valve_Stage1_ON, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ControlFlapClose_OFF, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ControlFlapClose_ON, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ControlFlapOpen_OFF, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ControlFlapOpen_ON, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Valve_Stage3_OFF, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Valve_Stage3_ON, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Valve_Stage2_OFF, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Valve_Stage2_ON, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Led_HighFlareTemp_OFF, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Led_HighFlareTemp_ON, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Led_LowNozPres_OFF, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Led_LowNozPres_ON, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Led_HighNozPres_OFF, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Led_HighNozPres_ON, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Led_Horn_OFF, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Led_Horn_ON, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Led_FlareINOper_OFF, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Led_FlareInOper_ON, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Led_CommonAlarm_OFF, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Led_CommonAlarm_ON, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Led_ReleaseFlare_OFF, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Led_ReleaseFlare_ON, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Led_ESD_OFF, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Led_ESD_ON, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Led_BCU_OFF, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Led_BCU_ON, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.sch1_R, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.sch1_C, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.sch1_L, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PID, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Flare2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Flare3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TimerGUI
        '
        Me.TimerGUI.Enabled = True
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(333, 459)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(74, 13)
        Me.Label12.TabIndex = 798
        Me.Label12.Text = "Valve Stage 3"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(333, 331)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(74, 13)
        Me.Label11.TabIndex = 795
        Me.Label11.Text = "Valve Stage 2"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(660, 497)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(114, 13)
        Me.Label10.TabIndex = 792
        Me.Label10.Text = "High Flare temperature"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(660, 471)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(103, 13)
        Me.Label9.TabIndex = 789
        Me.Label9.Text = "Low nozzle pressure"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(660, 445)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(105, 13)
        Me.Label8.TabIndex = 786
        Me.Label8.Text = "High nozzle pressure"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(660, 523)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(30, 13)
        Me.Label6.TabIndex = 783
        Me.Label6.Text = "Horn"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(660, 350)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(85, 13)
        Me.Label7.TabIndex = 779
        Me.Label7.Text = "Emergency Stop"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(660, 300)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(90, 13)
        Me.Label4.TabIndex = 778
        Me.Label4.Text = "Flare in Operetion"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(660, 421)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(77, 13)
        Me.Label3.TabIndex = 777
        Me.Label3.Text = "Common Alarm"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(660, 324)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(72, 13)
        Me.Label5.TabIndex = 776
        Me.Label5.Text = "Release Flare"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(660, 397)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(52, 13)
        Me.Label13.TabIndex = 768
        Me.Label13.Text = "BCU fault"
        '
        'Label59
        '
        Me.Label59.AutoSize = True
        Me.Label59.Location = New System.Drawing.Point(634, 376)
        Me.Label59.Name = "Label59"
        Me.Label59.Size = New System.Drawing.Size(48, 13)
        Me.Label59.TabIndex = 765
        Me.Label59.Text = "FAULTS"
        '
        'Position
        '
        Me.Position.Location = New System.Drawing.Point(99, 265)
        Me.Position.Maximum = 31648
        Me.Position.Minimum = -1000
        Me.Position.Name = "Position"
        Me.Position.Size = New System.Drawing.Size(208, 45)
        Me.Position.TabIndex = 763
        Me.Position.TickFrequency = 1000
        Me.Position.Value = 12567
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(99, 251)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(44, 13)
        Me.Label2.TabIndex = 762
        Me.Label2.Text = "Position"
        '
        'Temperature
        '
        Me.Temperature.Location = New System.Drawing.Point(99, 214)
        Me.Temperature.Maximum = 31648
        Me.Temperature.Minimum = -1000
        Me.Temperature.Name = "Temperature"
        Me.Temperature.Size = New System.Drawing.Size(328, 45)
        Me.Temperature.TabIndex = 761
        Me.Temperature.TickFrequency = 1000
        Me.Temperature.Value = 22120
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(99, 198)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(67, 13)
        Me.Label1.TabIndex = 760
        Me.Label1.Text = "Temperature"
        '
        'Pressure
        '
        Me.Pressure.Location = New System.Drawing.Point(99, 161)
        Me.Pressure.Maximum = 31648
        Me.Pressure.Minimum = -1000
        Me.Pressure.Name = "Pressure"
        Me.Pressure.Size = New System.Drawing.Size(328, 45)
        Me.Pressure.TabIndex = 759
        Me.Pressure.TickFrequency = 1000
        Me.Pressure.Value = 2350
        '
        'LabelValue
        '
        Me.LabelValue.AutoSize = True
        Me.LabelValue.Location = New System.Drawing.Point(99, 145)
        Me.LabelValue.Name = "LabelValue"
        Me.LabelValue.Size = New System.Drawing.Size(48, 13)
        Me.LabelValue.TabIndex = 758
        Me.LabelValue.Text = "Pressure"
        '
        'Bsch1_R
        '
        Me.Bsch1_R.AutoSize = True
        Me.Bsch1_R.Location = New System.Drawing.Point(716, 168)
        Me.Bsch1_R.Name = "Bsch1_R"
        Me.Bsch1_R.Size = New System.Drawing.Size(41, 13)
        Me.Bsch1_R.TabIndex = 752
        Me.Bsch1_R.Text = "LOCAL"
        '
        'Bsch1_C
        '
        Me.Bsch1_C.AutoSize = True
        Me.Bsch1_C.Location = New System.Drawing.Point(696, 160)
        Me.Bsch1_C.Name = "Bsch1_C"
        Me.Bsch1_C.Size = New System.Drawing.Size(15, 13)
        Me.Bsch1_C.TabIndex = 751
        Me.Bsch1_C.Text = "O"
        '
        'Bsch1_L
        '
        Me.Bsch1_L.AutoSize = True
        Me.Bsch1_L.Location = New System.Drawing.Point(642, 168)
        Me.Bsch1_L.Name = "Bsch1_L"
        Me.Bsch1_L.Size = New System.Drawing.Size(53, 13)
        Me.Bsch1_L.TabIndex = 750
        Me.Bsch1_L.Text = "REMOTE"
        '
        'Label263
        '
        Me.Label263.AutoSize = True
        Me.Label263.Location = New System.Drawing.Point(682, 146)
        Me.Label263.Name = "Label263"
        Me.Label263.Size = New System.Drawing.Size(41, 13)
        Me.Label263.TabIndex = 746
        Me.Label263.Text = "FLARE"
        '
        'FlareInOperation
        '
        Me.FlareInOperation.AutoSize = True
        Me.FlareInOperation.Checked = True
        Me.FlareInOperation.CheckState = System.Windows.Forms.CheckState.Checked
        Me.FlareInOperation.Location = New System.Drawing.Point(637, 100)
        Me.FlareInOperation.Name = "FlareInOperation"
        Me.FlareInOperation.Size = New System.Drawing.Size(109, 17)
        Me.FlareInOperation.TabIndex = 745
        Me.FlareInOperation.Text = "Flare in Operetion"
        Me.FlareInOperation.UseVisualStyleBackColor = True
        '
        'ReleaseFlare
        '
        Me.ReleaseFlare.AutoSize = True
        Me.ReleaseFlare.Location = New System.Drawing.Point(637, 82)
        Me.ReleaseFlare.Name = "ReleaseFlare"
        Me.ReleaseFlare.Size = New System.Drawing.Size(91, 17)
        Me.ReleaseFlare.TabIndex = 744
        Me.ReleaseFlare.Text = "Release Flare"
        Me.ReleaseFlare.UseVisualStyleBackColor = True
        '
        'BCUFault
        '
        Me.BCUFault.AutoSize = True
        Me.BCUFault.Location = New System.Drawing.Point(637, 64)
        Me.BCUFault.Name = "BCUFault"
        Me.BCUFault.Size = New System.Drawing.Size(74, 17)
        Me.BCUFault.TabIndex = 743
        Me.BCUFault.Text = "BCU Fault"
        Me.BCUFault.UseVisualStyleBackColor = True
        '
        'ESD_LCP
        '
        Me.ESD_LCP.AutoSize = True
        Me.ESD_LCP.Location = New System.Drawing.Point(637, 46)
        Me.ESD_LCP.Name = "ESD_LCP"
        Me.ESD_LCP.Size = New System.Drawing.Size(127, 17)
        Me.ESD_LCP.TabIndex = 742
        Me.ESD_LCP.Text = "Emergency Stop LCP"
        Me.ESD_LCP.UseVisualStyleBackColor = True
        '
        'ESD_CUST
        '
        Me.ESD_CUST.AutoSize = True
        Me.ESD_CUST.Location = New System.Drawing.Point(637, 28)
        Me.ESD_CUST.Name = "ESD_CUST"
        Me.ESD_CUST.Size = New System.Drawing.Size(131, 17)
        Me.ESD_CUST.TabIndex = 741
        Me.ESD_CUST.Text = "Emergency Stop Cust."
        Me.ESD_CUST.UseVisualStyleBackColor = True
        '
        'ButtonResetLCP
        '
        Me.ButtonResetLCP.Location = New System.Drawing.Point(637, 198)
        Me.ButtonResetLCP.Name = "ButtonResetLCP"
        Me.ButtonResetLCP.Size = New System.Drawing.Size(100, 23)
        Me.ButtonResetLCP.TabIndex = 740
        Me.ButtonResetLCP.Text = "Reset on LCP"
        Me.ButtonResetLCP.UseVisualStyleBackColor = True
        '
        'ButtonReset
        '
        Me.ButtonReset.Location = New System.Drawing.Point(637, 227)
        Me.ButtonReset.Name = "ButtonReset"
        Me.ButtonReset.Size = New System.Drawing.Size(100, 23)
        Me.ButtonReset.TabIndex = 739
        Me.ButtonReset.Text = "Reset customer"
        Me.ButtonReset.UseVisualStyleBackColor = True
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(8, 71)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(61, 13)
        Me.Label16.TabIndex = 808
        Me.Label16.Text = "Range min."
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(8, 30)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(64, 13)
        Me.Label17.TabIndex = 807
        Me.Label17.Text = "Range max."
        '
        'RangeMin
        '
        Me.RangeMin.Increment = New Decimal(New Integer() {10, 0, 0, 0})
        Me.RangeMin.Location = New System.Drawing.Point(8, 87)
        Me.RangeMin.Maximum = New Decimal(New Integer() {0, 0, 0, 0})
        Me.RangeMin.Minimum = New Decimal(New Integer() {6000, 0, 0, -2147483648})
        Me.RangeMin.Name = "RangeMin"
        Me.RangeMin.Size = New System.Drawing.Size(50, 20)
        Me.RangeMin.TabIndex = 806
        '
        'RangeMax
        '
        Me.RangeMax.Increment = New Decimal(New Integer() {10, 0, 0, 0})
        Me.RangeMax.Location = New System.Drawing.Point(8, 46)
        Me.RangeMax.Maximum = New Decimal(New Integer() {32700, 0, 0, 0})
        Me.RangeMax.Minimum = New Decimal(New Integer() {27648, 0, 0, 0})
        Me.RangeMax.Name = "RangeMax"
        Me.RangeMax.Size = New System.Drawing.Size(50, 20)
        Me.RangeMax.TabIndex = 805
        Me.RangeMax.Value = New Decimal(New Integer() {27648, 0, 0, 0})
        '
        'CBRange
        '
        Me.CBRange.AutoSize = True
        Me.CBRange.Location = New System.Drawing.Point(8, 9)
        Me.CBRange.Name = "CBRange"
        Me.CBRange.Size = New System.Drawing.Size(89, 17)
        Me.CBRange.TabIndex = 809
        Me.CBRange.Text = "Normal range"
        Me.CBRange.UseVisualStyleBackColor = True
        '
        'LabelPR
        '
        Me.LabelPR.AutoSize = True
        Me.LabelPR.Location = New System.Drawing.Point(178, 145)
        Me.LabelPR.Name = "LabelPR"
        Me.LabelPR.Size = New System.Drawing.Size(47, 13)
        Me.LabelPR.TabIndex = 811
        Me.LabelPR.Text = "pressure"
        '
        'LabelTemp
        '
        Me.LabelTemp.AutoSize = True
        Me.LabelTemp.Location = New System.Drawing.Point(178, 197)
        Me.LabelTemp.Name = "LabelTemp"
        Me.LabelTemp.Size = New System.Drawing.Size(63, 13)
        Me.LabelTemp.TabIndex = 812
        Me.LabelTemp.Text = "temperature"
        '
        'LabelPos
        '
        Me.LabelPos.AutoSize = True
        Me.LabelPos.Location = New System.Drawing.Point(178, 249)
        Me.LabelPos.Name = "LabelPos"
        Me.LabelPos.Size = New System.Drawing.Size(43, 13)
        Me.LabelPos.TabIndex = 813
        Me.LabelPos.Text = "position"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(634, 9)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(47, 13)
        Me.Label18.TabIndex = 814
        Me.Label18.Text = "INPUTS"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(1014, 290)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(59, 13)
        Me.Label19.TabIndex = 815
        Me.Label19.Text = "OUTPUTS"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(484, 512)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(37, 13)
        Me.Label15.TabIndex = 801
        Me.Label15.Text = "OPEN"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(539, 512)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(42, 13)
        Me.Label14.TabIndex = 816
        Me.Label14.Text = "CLOSE"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(634, 280)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(59, 13)
        Me.Label20.TabIndex = 817
        Me.Label20.Text = "OUTPUTS"
        '
        'LabelFlow
        '
        Me.LabelFlow.AutoSize = True
        Me.LabelFlow.Location = New System.Drawing.Point(195, 331)
        Me.LabelFlow.Name = "LabelFlow"
        Me.LabelFlow.Size = New System.Drawing.Size(57, 13)
        Me.LabelFlow.TabIndex = 820
        Me.LabelFlow.Text = "Flow m3/h"
        '
        'LabelAutoManual
        '
        Me.LabelAutoManual.AutoSize = True
        Me.LabelAutoManual.Location = New System.Drawing.Point(333, 262)
        Me.LabelAutoManual.Name = "LabelAutoManual"
        Me.LabelAutoManual.Size = New System.Drawing.Size(65, 13)
        Me.LabelAutoManual.TabIndex = 821
        Me.LabelAutoManual.Text = "Mode - Auto"
        '
        'CheckBoxSimTemp
        '
        Me.CheckBoxSimTemp.AutoSize = True
        Me.CheckBoxSimTemp.Checked = True
        Me.CheckBoxSimTemp.CheckState = System.Windows.Forms.CheckState.Checked
        Me.CheckBoxSimTemp.Location = New System.Drawing.Point(8, 195)
        Me.CheckBoxSimTemp.Name = "CheckBoxSimTemp"
        Me.CheckBoxSimTemp.Size = New System.Drawing.Size(50, 17)
        Me.CheckBoxSimTemp.TabIndex = 822
        Me.CheckBoxSimTemp.Text = "Tem."
        Me.CheckBoxSimTemp.UseVisualStyleBackColor = True
        '
        'LabelPID
        '
        Me.LabelPID.AutoSize = True
        Me.LabelPID.Location = New System.Drawing.Point(13, 443)
        Me.LabelPID.Name = "LabelPID"
        Me.LabelPID.Size = New System.Drawing.Size(35, 13)
        Me.LabelPID.TabIndex = 823
        Me.LabelPID.Text = "SPpid"
        '
        'NumericUpDownSimT
        '
        Me.NumericUpDownSimT.Location = New System.Drawing.Point(8, 214)
        Me.NumericUpDownSimT.Maximum = New Decimal(New Integer() {20, 0, 0, 0})
        Me.NumericUpDownSimT.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NumericUpDownSimT.Name = "NumericUpDownSimT"
        Me.NumericUpDownSimT.Size = New System.Drawing.Size(47, 20)
        Me.NumericUpDownSimT.TabIndex = 824
        Me.NumericUpDownSimT.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'NumericUpDownSimPos
        '
        Me.NumericUpDownSimPos.Location = New System.Drawing.Point(8, 265)
        Me.NumericUpDownSimPos.Maximum = New Decimal(New Integer() {20, 0, 0, 0})
        Me.NumericUpDownSimPos.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NumericUpDownSimPos.Name = "NumericUpDownSimPos"
        Me.NumericUpDownSimPos.Size = New System.Drawing.Size(47, 20)
        Me.NumericUpDownSimPos.TabIndex = 825
        Me.NumericUpDownSimPos.Value = New Decimal(New Integer() {5, 0, 0, 0})
        '
        'CheckBoxSimPos
        '
        Me.CheckBoxSimPos.AutoSize = True
        Me.CheckBoxSimPos.Checked = True
        Me.CheckBoxSimPos.CheckState = System.Windows.Forms.CheckState.Checked
        Me.CheckBoxSimPos.Location = New System.Drawing.Point(8, 249)
        Me.CheckBoxSimPos.Name = "CheckBoxSimPos"
        Me.CheckBoxSimPos.Size = New System.Drawing.Size(47, 17)
        Me.CheckBoxSimPos.TabIndex = 826
        Me.CheckBoxSimPos.Text = "Pos."
        Me.CheckBoxSimPos.UseVisualStyleBackColor = True
        '
        'StartUpPressure
        '
        Me.StartUpPressure.AutoSize = True
        Me.StartUpPressure.Location = New System.Drawing.Point(637, 118)
        Me.StartUpPressure.Name = "StartUpPressure"
        Me.StartUpPressure.Size = New System.Drawing.Size(105, 17)
        Me.StartUpPressure.TabIndex = 827
        Me.StartUpPressure.Text = "StartUp pressure"
        Me.StartUpPressure.UseVisualStyleBackColor = True
        '
        'LedCH1
        '
        Me.LedCH1.BackColor = System.Drawing.Color.Green
        Me.LedCH1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LedCH1.Location = New System.Drawing.Point(143, 424)
        Me.LedCH1.Name = "LedCH1"
        Me.LedCH1.Size = New System.Drawing.Size(13, 13)
        Me.LedCH1.TabIndex = 828
        '
        'LedCH2
        '
        Me.LedCH2.BackColor = System.Drawing.Color.Lime
        Me.LedCH2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LedCH2.Location = New System.Drawing.Point(143, 443)
        Me.LedCH2.Name = "LedCH2"
        Me.LedCH2.Size = New System.Drawing.Size(13, 13)
        Me.LedCH2.TabIndex = 830
        '
        'LedCH3
        '
        Me.LedCH3.BackColor = System.Drawing.Color.Green
        Me.LedCH3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LedCH3.Location = New System.Drawing.Point(143, 464)
        Me.LedCH3.Name = "LedCH3"
        Me.LedCH3.Size = New System.Drawing.Size(13, 13)
        Me.LedCH3.TabIndex = 832
        '
        'LedCH4
        '
        Me.LedCH4.BackColor = System.Drawing.Color.Green
        Me.LedCH4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LedCH4.Location = New System.Drawing.Point(143, 485)
        Me.LedCH4.Name = "LedCH4"
        Me.LedCH4.Size = New System.Drawing.Size(13, 13)
        Me.LedCH4.TabIndex = 830
        '
        'LedCH5
        '
        Me.LedCH5.BackColor = System.Drawing.Color.Green
        Me.LedCH5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LedCH5.Location = New System.Drawing.Point(143, 505)
        Me.LedCH5.Name = "LedCH5"
        Me.LedCH5.Size = New System.Drawing.Size(13, 13)
        Me.LedCH5.TabIndex = 832
        '
        'LabelCH5
        '
        Me.LabelCH5.AutoSize = True
        Me.LabelCH5.Location = New System.Drawing.Point(227, 505)
        Me.LabelCH5.Name = "LabelCH5"
        Me.LabelCH5.Size = New System.Drawing.Size(25, 13)
        Me.LabelCH5.TabIndex = 837
        Me.LabelCH5.Text = "ch5"
        '
        'LabelCH4
        '
        Me.LabelCH4.AutoSize = True
        Me.LabelCH4.Location = New System.Drawing.Point(227, 485)
        Me.LabelCH4.Name = "LabelCH4"
        Me.LabelCH4.Size = New System.Drawing.Size(25, 13)
        Me.LabelCH4.TabIndex = 836
        Me.LabelCH4.Text = "ch4"
        '
        'LabelCH3
        '
        Me.LabelCH3.AutoSize = True
        Me.LabelCH3.Location = New System.Drawing.Point(227, 464)
        Me.LabelCH3.Name = "LabelCH3"
        Me.LabelCH3.Size = New System.Drawing.Size(25, 13)
        Me.LabelCH3.TabIndex = 838
        Me.LabelCH3.Text = "ch3"
        '
        'LabelCH2
        '
        Me.LabelCH2.AutoSize = True
        Me.LabelCH2.Location = New System.Drawing.Point(227, 443)
        Me.LabelCH2.Name = "LabelCH2"
        Me.LabelCH2.Size = New System.Drawing.Size(25, 13)
        Me.LabelCH2.TabIndex = 835
        Me.LabelCH2.Text = "ch2"
        '
        'LabelCH1
        '
        Me.LabelCH1.AutoSize = True
        Me.LabelCH1.Location = New System.Drawing.Point(227, 424)
        Me.LabelCH1.Name = "LabelCH1"
        Me.LabelCH1.Size = New System.Drawing.Size(25, 13)
        Me.LabelCH1.TabIndex = 834
        Me.LabelCH1.Text = "ch1"
        '
        'LabelSPPos
        '
        Me.LabelSPPos.AutoSize = True
        Me.LabelSPPos.Location = New System.Drawing.Point(313, 494)
        Me.LabelSPPos.Name = "LabelSPPos"
        Me.LabelSPPos.Size = New System.Drawing.Size(38, 13)
        Me.LabelSPPos.TabIndex = 839
        Me.LabelSPPos.Text = "SPpos"
        '
        'LabelChan1
        '
        Me.LabelChan1.AutoSize = True
        Me.LabelChan1.Location = New System.Drawing.Point(162, 424)
        Me.LabelChan1.Name = "LabelChan1"
        Me.LabelChan1.Size = New System.Drawing.Size(45, 13)
        Me.LabelChan1.TabIndex = 840
        Me.LabelChan1.Text = "Label21"
        '
        'LabelChan2
        '
        Me.LabelChan2.AutoSize = True
        Me.LabelChan2.Location = New System.Drawing.Point(162, 443)
        Me.LabelChan2.Name = "LabelChan2"
        Me.LabelChan2.Size = New System.Drawing.Size(45, 13)
        Me.LabelChan2.TabIndex = 841
        Me.LabelChan2.Text = "Label21"
        '
        'LabelChan3
        '
        Me.LabelChan3.AutoSize = True
        Me.LabelChan3.Location = New System.Drawing.Point(162, 464)
        Me.LabelChan3.Name = "LabelChan3"
        Me.LabelChan3.Size = New System.Drawing.Size(45, 13)
        Me.LabelChan3.TabIndex = 842
        Me.LabelChan3.Text = "Label21"
        '
        'LabelChan4
        '
        Me.LabelChan4.AutoSize = True
        Me.LabelChan4.Location = New System.Drawing.Point(162, 485)
        Me.LabelChan4.Name = "LabelChan4"
        Me.LabelChan4.Size = New System.Drawing.Size(45, 13)
        Me.LabelChan4.TabIndex = 843
        Me.LabelChan4.Text = "Label21"
        '
        'LabelChan5
        '
        Me.LabelChan5.AutoSize = True
        Me.LabelChan5.Location = New System.Drawing.Point(162, 505)
        Me.LabelChan5.Name = "LabelChan5"
        Me.LabelChan5.Size = New System.Drawing.Size(45, 13)
        Me.LabelChan5.TabIndex = 844
        Me.LabelChan5.Text = "Label21"
        '
        'LabelSPtem
        '
        Me.LabelSPtem.AutoSize = True
        Me.LabelSPtem.Location = New System.Drawing.Point(17, 424)
        Me.LabelSPtem.Name = "LabelSPtem"
        Me.LabelSPtem.Size = New System.Drawing.Size(38, 13)
        Me.LabelSPtem.TabIndex = 845
        Me.LabelSPtem.Text = "SPtem"
        '
        'CheckBoxSimOn
        '
        Me.CheckBoxSimOn.AutoSize = True
        Me.CheckBoxSimOn.Location = New System.Drawing.Point(8, 160)
        Me.CheckBoxSimOn.Name = "CheckBoxSimOn"
        Me.CheckBoxSimOn.Size = New System.Drawing.Size(40, 17)
        Me.CheckBoxSimOn.TabIndex = 846
        Me.CheckBoxSimOn.Text = "Off"
        Me.CheckBoxSimOn.UseVisualStyleBackColor = True
        '
        'Flare1
        '
        Me.Flare1.Image = Global.BioGas.My.Resources.Resources.flare
        Me.Flare1.InitialImage = Nothing
        Me.Flare1.Location = New System.Drawing.Point(506, 87)
        Me.Flare1.Name = "Flare1"
        Me.Flare1.Size = New System.Drawing.Size(27, 71)
        Me.Flare1.TabIndex = 847
        Me.Flare1.TabStop = False
        '
        'Valve_Stage1_OFF
        '
        Me.Valve_Stage1_OFF.Image = CType(resources.GetObject("Valve_Stage1_OFF.Image"), System.Drawing.Image)
        Me.Valve_Stage1_OFF.InitialImage = Nothing
        Me.Valve_Stage1_OFF.Location = New System.Drawing.Point(143, 375)
        Me.Valve_Stage1_OFF.Name = "Valve_Stage1_OFF"
        Me.Valve_Stage1_OFF.Size = New System.Drawing.Size(32, 20)
        Me.Valve_Stage1_OFF.TabIndex = 819
        Me.Valve_Stage1_OFF.TabStop = False
        '
        'Valve_Stage1_ON
        '
        Me.Valve_Stage1_ON.Image = CType(resources.GetObject("Valve_Stage1_ON.Image"), System.Drawing.Image)
        Me.Valve_Stage1_ON.InitialImage = Nothing
        Me.Valve_Stage1_ON.Location = New System.Drawing.Point(143, 375)
        Me.Valve_Stage1_ON.Name = "Valve_Stage1_ON"
        Me.Valve_Stage1_ON.Size = New System.Drawing.Size(32, 20)
        Me.Valve_Stage1_ON.TabIndex = 818
        Me.Valve_Stage1_ON.TabStop = False
        Me.Valve_Stage1_ON.Visible = False
        '
        'ControlFlapClose_OFF
        '
        Me.ControlFlapClose_OFF.Image = Global.BioGas.My.Resources.Resources.klepCont_off
        Me.ControlFlapClose_OFF.InitialImage = Nothing
        Me.ControlFlapClose_OFF.Location = New System.Drawing.Point(521, 510)
        Me.ControlFlapClose_OFF.Name = "ControlFlapClose_OFF"
        Me.ControlFlapClose_OFF.Size = New System.Drawing.Size(16, 18)
        Me.ControlFlapClose_OFF.TabIndex = 803
        Me.ControlFlapClose_OFF.TabStop = False
        '
        'ControlFlapClose_ON
        '
        Me.ControlFlapClose_ON.Image = Global.BioGas.My.Resources.Resources.klepCont_on
        Me.ControlFlapClose_ON.InitialImage = Nothing
        Me.ControlFlapClose_ON.Location = New System.Drawing.Point(521, 510)
        Me.ControlFlapClose_ON.Name = "ControlFlapClose_ON"
        Me.ControlFlapClose_ON.Size = New System.Drawing.Size(16, 18)
        Me.ControlFlapClose_ON.TabIndex = 802
        Me.ControlFlapClose_ON.TabStop = False
        Me.ControlFlapClose_ON.Visible = False
        '
        'ControlFlapOpen_OFF
        '
        Me.ControlFlapOpen_OFF.Image = Global.BioGas.My.Resources.Resources.klepCont_off
        Me.ControlFlapOpen_OFF.InitialImage = Nothing
        Me.ControlFlapOpen_OFF.Location = New System.Drawing.Point(466, 510)
        Me.ControlFlapOpen_OFF.Name = "ControlFlapOpen_OFF"
        Me.ControlFlapOpen_OFF.Size = New System.Drawing.Size(16, 18)
        Me.ControlFlapOpen_OFF.TabIndex = 800
        Me.ControlFlapOpen_OFF.TabStop = False
        '
        'ControlFlapOpen_ON
        '
        Me.ControlFlapOpen_ON.Image = Global.BioGas.My.Resources.Resources.klepCont_on
        Me.ControlFlapOpen_ON.InitialImage = Nothing
        Me.ControlFlapOpen_ON.Location = New System.Drawing.Point(466, 510)
        Me.ControlFlapOpen_ON.Name = "ControlFlapOpen_ON"
        Me.ControlFlapOpen_ON.Size = New System.Drawing.Size(16, 18)
        Me.ControlFlapOpen_ON.TabIndex = 799
        Me.ControlFlapOpen_ON.TabStop = False
        Me.ControlFlapOpen_ON.Visible = False
        '
        'Valve_Stage3_OFF
        '
        Me.Valve_Stage3_OFF.Image = CType(resources.GetObject("Valve_Stage3_OFF.Image"), System.Drawing.Image)
        Me.Valve_Stage3_OFF.InitialImage = Nothing
        Me.Valve_Stage3_OFF.Location = New System.Drawing.Point(351, 438)
        Me.Valve_Stage3_OFF.Name = "Valve_Stage3_OFF"
        Me.Valve_Stage3_OFF.Size = New System.Drawing.Size(32, 20)
        Me.Valve_Stage3_OFF.TabIndex = 797
        Me.Valve_Stage3_OFF.TabStop = False
        '
        'Valve_Stage3_ON
        '
        Me.Valve_Stage3_ON.Image = CType(resources.GetObject("Valve_Stage3_ON.Image"), System.Drawing.Image)
        Me.Valve_Stage3_ON.InitialImage = Nothing
        Me.Valve_Stage3_ON.Location = New System.Drawing.Point(351, 438)
        Me.Valve_Stage3_ON.Name = "Valve_Stage3_ON"
        Me.Valve_Stage3_ON.Size = New System.Drawing.Size(32, 20)
        Me.Valve_Stage3_ON.TabIndex = 796
        Me.Valve_Stage3_ON.TabStop = False
        Me.Valve_Stage3_ON.Visible = False
        '
        'Valve_Stage2_OFF
        '
        Me.Valve_Stage2_OFF.Image = CType(resources.GetObject("Valve_Stage2_OFF.Image"), System.Drawing.Image)
        Me.Valve_Stage2_OFF.InitialImage = Nothing
        Me.Valve_Stage2_OFF.Location = New System.Drawing.Point(351, 310)
        Me.Valve_Stage2_OFF.Name = "Valve_Stage2_OFF"
        Me.Valve_Stage2_OFF.Size = New System.Drawing.Size(32, 20)
        Me.Valve_Stage2_OFF.TabIndex = 794
        Me.Valve_Stage2_OFF.TabStop = False
        '
        'Valve_Stage2_ON
        '
        Me.Valve_Stage2_ON.Image = CType(resources.GetObject("Valve_Stage2_ON.Image"), System.Drawing.Image)
        Me.Valve_Stage2_ON.InitialImage = Nothing
        Me.Valve_Stage2_ON.Location = New System.Drawing.Point(351, 310)
        Me.Valve_Stage2_ON.Name = "Valve_Stage2_ON"
        Me.Valve_Stage2_ON.Size = New System.Drawing.Size(32, 20)
        Me.Valve_Stage2_ON.TabIndex = 793
        Me.Valve_Stage2_ON.TabStop = False
        Me.Valve_Stage2_ON.Visible = False
        '
        'Led_HighFlareTemp_OFF
        '
        Me.Led_HighFlareTemp_OFF.Image = CType(resources.GetObject("Led_HighFlareTemp_OFF.Image"), System.Drawing.Image)
        Me.Led_HighFlareTemp_OFF.InitialImage = Nothing
        Me.Led_HighFlareTemp_OFF.Location = New System.Drawing.Point(634, 492)
        Me.Led_HighFlareTemp_OFF.Name = "Led_HighFlareTemp_OFF"
        Me.Led_HighFlareTemp_OFF.Size = New System.Drawing.Size(20, 20)
        Me.Led_HighFlareTemp_OFF.TabIndex = 791
        Me.Led_HighFlareTemp_OFF.TabStop = False
        '
        'Led_HighFlareTemp_ON
        '
        Me.Led_HighFlareTemp_ON.Image = CType(resources.GetObject("Led_HighFlareTemp_ON.Image"), System.Drawing.Image)
        Me.Led_HighFlareTemp_ON.InitialImage = Nothing
        Me.Led_HighFlareTemp_ON.Location = New System.Drawing.Point(634, 492)
        Me.Led_HighFlareTemp_ON.Name = "Led_HighFlareTemp_ON"
        Me.Led_HighFlareTemp_ON.Size = New System.Drawing.Size(20, 20)
        Me.Led_HighFlareTemp_ON.TabIndex = 790
        Me.Led_HighFlareTemp_ON.TabStop = False
        Me.Led_HighFlareTemp_ON.Visible = False
        '
        'Led_LowNozPres_OFF
        '
        Me.Led_LowNozPres_OFF.Image = CType(resources.GetObject("Led_LowNozPres_OFF.Image"), System.Drawing.Image)
        Me.Led_LowNozPres_OFF.InitialImage = Nothing
        Me.Led_LowNozPres_OFF.Location = New System.Drawing.Point(634, 467)
        Me.Led_LowNozPres_OFF.Name = "Led_LowNozPres_OFF"
        Me.Led_LowNozPres_OFF.Size = New System.Drawing.Size(20, 20)
        Me.Led_LowNozPres_OFF.TabIndex = 788
        Me.Led_LowNozPres_OFF.TabStop = False
        '
        'Led_LowNozPres_ON
        '
        Me.Led_LowNozPres_ON.Image = CType(resources.GetObject("Led_LowNozPres_ON.Image"), System.Drawing.Image)
        Me.Led_LowNozPres_ON.InitialImage = Nothing
        Me.Led_LowNozPres_ON.Location = New System.Drawing.Point(634, 467)
        Me.Led_LowNozPres_ON.Name = "Led_LowNozPres_ON"
        Me.Led_LowNozPres_ON.Size = New System.Drawing.Size(20, 20)
        Me.Led_LowNozPres_ON.TabIndex = 787
        Me.Led_LowNozPres_ON.TabStop = False
        Me.Led_LowNozPres_ON.Visible = False
        '
        'Led_HighNozPres_OFF
        '
        Me.Led_HighNozPres_OFF.Image = CType(resources.GetObject("Led_HighNozPres_OFF.Image"), System.Drawing.Image)
        Me.Led_HighNozPres_OFF.InitialImage = Nothing
        Me.Led_HighNozPres_OFF.Location = New System.Drawing.Point(634, 442)
        Me.Led_HighNozPres_OFF.Name = "Led_HighNozPres_OFF"
        Me.Led_HighNozPres_OFF.Size = New System.Drawing.Size(20, 20)
        Me.Led_HighNozPres_OFF.TabIndex = 785
        Me.Led_HighNozPres_OFF.TabStop = False
        '
        'Led_HighNozPres_ON
        '
        Me.Led_HighNozPres_ON.Image = CType(resources.GetObject("Led_HighNozPres_ON.Image"), System.Drawing.Image)
        Me.Led_HighNozPres_ON.InitialImage = Nothing
        Me.Led_HighNozPres_ON.Location = New System.Drawing.Point(634, 442)
        Me.Led_HighNozPres_ON.Name = "Led_HighNozPres_ON"
        Me.Led_HighNozPres_ON.Size = New System.Drawing.Size(20, 20)
        Me.Led_HighNozPres_ON.TabIndex = 784
        Me.Led_HighNozPres_ON.TabStop = False
        Me.Led_HighNozPres_ON.Visible = False
        '
        'Led_Horn_OFF
        '
        Me.Led_Horn_OFF.Image = Global.BioGas.My.Resources.Resources.ledR_off
        Me.Led_Horn_OFF.InitialImage = Nothing
        Me.Led_Horn_OFF.Location = New System.Drawing.Point(634, 517)
        Me.Led_Horn_OFF.Name = "Led_Horn_OFF"
        Me.Led_Horn_OFF.Size = New System.Drawing.Size(20, 20)
        Me.Led_Horn_OFF.TabIndex = 782
        Me.Led_Horn_OFF.TabStop = False
        '
        'Led_Horn_ON
        '
        Me.Led_Horn_ON.Image = Global.BioGas.My.Resources.Resources.ledR_on
        Me.Led_Horn_ON.InitialImage = Nothing
        Me.Led_Horn_ON.Location = New System.Drawing.Point(634, 517)
        Me.Led_Horn_ON.Name = "Led_Horn_ON"
        Me.Led_Horn_ON.Size = New System.Drawing.Size(20, 20)
        Me.Led_Horn_ON.TabIndex = 781
        Me.Led_Horn_ON.TabStop = False
        Me.Led_Horn_ON.Visible = False
        '
        'Led_FlareINOper_OFF
        '
        Me.Led_FlareINOper_OFF.Image = Global.BioGas.My.Resources.Resources.ledG_off
        Me.Led_FlareINOper_OFF.InitialImage = Nothing
        Me.Led_FlareINOper_OFF.Location = New System.Drawing.Point(634, 296)
        Me.Led_FlareINOper_OFF.Name = "Led_FlareINOper_OFF"
        Me.Led_FlareINOper_OFF.Size = New System.Drawing.Size(20, 20)
        Me.Led_FlareINOper_OFF.TabIndex = 775
        Me.Led_FlareINOper_OFF.TabStop = False
        '
        'Led_FlareInOper_ON
        '
        Me.Led_FlareInOper_ON.Image = Global.BioGas.My.Resources.Resources.ledG_on
        Me.Led_FlareInOper_ON.InitialImage = Nothing
        Me.Led_FlareInOper_ON.Location = New System.Drawing.Point(634, 296)
        Me.Led_FlareInOper_ON.Name = "Led_FlareInOper_ON"
        Me.Led_FlareInOper_ON.Size = New System.Drawing.Size(20, 20)
        Me.Led_FlareInOper_ON.TabIndex = 774
        Me.Led_FlareInOper_ON.TabStop = False
        Me.Led_FlareInOper_ON.Visible = False
        '
        'Led_CommonAlarm_OFF
        '
        Me.Led_CommonAlarm_OFF.Image = Global.BioGas.My.Resources.Resources.ledR_off
        Me.Led_CommonAlarm_OFF.InitialImage = Nothing
        Me.Led_CommonAlarm_OFF.Location = New System.Drawing.Point(634, 417)
        Me.Led_CommonAlarm_OFF.Name = "Led_CommonAlarm_OFF"
        Me.Led_CommonAlarm_OFF.Size = New System.Drawing.Size(20, 20)
        Me.Led_CommonAlarm_OFF.TabIndex = 773
        Me.Led_CommonAlarm_OFF.TabStop = False
        '
        'Led_CommonAlarm_ON
        '
        Me.Led_CommonAlarm_ON.Image = Global.BioGas.My.Resources.Resources.ledR_on
        Me.Led_CommonAlarm_ON.InitialImage = Nothing
        Me.Led_CommonAlarm_ON.Location = New System.Drawing.Point(634, 417)
        Me.Led_CommonAlarm_ON.Name = "Led_CommonAlarm_ON"
        Me.Led_CommonAlarm_ON.Size = New System.Drawing.Size(20, 20)
        Me.Led_CommonAlarm_ON.TabIndex = 772
        Me.Led_CommonAlarm_ON.TabStop = False
        Me.Led_CommonAlarm_ON.Visible = False
        '
        'Led_ReleaseFlare_OFF
        '
        Me.Led_ReleaseFlare_OFF.Image = Global.BioGas.My.Resources.Resources.ledG_off
        Me.Led_ReleaseFlare_OFF.InitialImage = Nothing
        Me.Led_ReleaseFlare_OFF.Location = New System.Drawing.Point(634, 321)
        Me.Led_ReleaseFlare_OFF.Name = "Led_ReleaseFlare_OFF"
        Me.Led_ReleaseFlare_OFF.Size = New System.Drawing.Size(20, 20)
        Me.Led_ReleaseFlare_OFF.TabIndex = 771
        Me.Led_ReleaseFlare_OFF.TabStop = False
        '
        'Led_ReleaseFlare_ON
        '
        Me.Led_ReleaseFlare_ON.Image = Global.BioGas.My.Resources.Resources.ledG_on
        Me.Led_ReleaseFlare_ON.InitialImage = Nothing
        Me.Led_ReleaseFlare_ON.Location = New System.Drawing.Point(634, 321)
        Me.Led_ReleaseFlare_ON.Name = "Led_ReleaseFlare_ON"
        Me.Led_ReleaseFlare_ON.Size = New System.Drawing.Size(20, 20)
        Me.Led_ReleaseFlare_ON.TabIndex = 770
        Me.Led_ReleaseFlare_ON.TabStop = False
        Me.Led_ReleaseFlare_ON.Visible = False
        '
        'Led_ESD_OFF
        '
        Me.Led_ESD_OFF.Image = Global.BioGas.My.Resources.Resources.ledR_off
        Me.Led_ESD_OFF.InitialImage = Nothing
        Me.Led_ESD_OFF.Location = New System.Drawing.Point(634, 346)
        Me.Led_ESD_OFF.Name = "Led_ESD_OFF"
        Me.Led_ESD_OFF.Size = New System.Drawing.Size(20, 20)
        Me.Led_ESD_OFF.TabIndex = 769
        Me.Led_ESD_OFF.TabStop = False
        '
        'Led_ESD_ON
        '
        Me.Led_ESD_ON.Image = Global.BioGas.My.Resources.Resources.ledR_on
        Me.Led_ESD_ON.InitialImage = Nothing
        Me.Led_ESD_ON.Location = New System.Drawing.Point(634, 346)
        Me.Led_ESD_ON.Name = "Led_ESD_ON"
        Me.Led_ESD_ON.Size = New System.Drawing.Size(20, 20)
        Me.Led_ESD_ON.TabIndex = 767
        Me.Led_ESD_ON.TabStop = False
        Me.Led_ESD_ON.Visible = False
        '
        'Led_BCU_OFF
        '
        Me.Led_BCU_OFF.Image = Global.BioGas.My.Resources.Resources.ledR_off
        Me.Led_BCU_OFF.InitialImage = Nothing
        Me.Led_BCU_OFF.Location = New System.Drawing.Point(634, 392)
        Me.Led_BCU_OFF.Name = "Led_BCU_OFF"
        Me.Led_BCU_OFF.Size = New System.Drawing.Size(20, 20)
        Me.Led_BCU_OFF.TabIndex = 766
        Me.Led_BCU_OFF.TabStop = False
        '
        'Led_BCU_ON
        '
        Me.Led_BCU_ON.Image = Global.BioGas.My.Resources.Resources.ledR_on
        Me.Led_BCU_ON.InitialImage = Nothing
        Me.Led_BCU_ON.Location = New System.Drawing.Point(634, 392)
        Me.Led_BCU_ON.Name = "Led_BCU_ON"
        Me.Led_BCU_ON.Size = New System.Drawing.Size(20, 20)
        Me.Led_BCU_ON.TabIndex = 764
        Me.Led_BCU_ON.TabStop = False
        Me.Led_BCU_ON.Visible = False
        '
        'sch1_R
        '
        Me.sch1_R.Image = CType(resources.GetObject("sch1_R.Image"), System.Drawing.Image)
        Me.sch1_R.InitialImage = CType(resources.GetObject("sch1_R.InitialImage"), System.Drawing.Image)
        Me.sch1_R.Location = New System.Drawing.Point(695, 175)
        Me.sch1_R.Name = "sch1_R"
        Me.sch1_R.Size = New System.Drawing.Size(16, 16)
        Me.sch1_R.TabIndex = 747
        Me.sch1_R.TabStop = False
        Me.sch1_R.Visible = False
        '
        'sch1_C
        '
        Me.sch1_C.Image = CType(resources.GetObject("sch1_C.Image"), System.Drawing.Image)
        Me.sch1_C.InitialImage = CType(resources.GetObject("sch1_C.InitialImage"), System.Drawing.Image)
        Me.sch1_C.Location = New System.Drawing.Point(695, 175)
        Me.sch1_C.Name = "sch1_C"
        Me.sch1_C.Size = New System.Drawing.Size(16, 16)
        Me.sch1_C.TabIndex = 748
        Me.sch1_C.TabStop = False
        Me.sch1_C.Visible = False
        '
        'sch1_L
        '
        Me.sch1_L.Image = Global.BioGas.My.Resources.Resources.sch_L
        Me.sch1_L.InitialImage = CType(resources.GetObject("sch1_L.InitialImage"), System.Drawing.Image)
        Me.sch1_L.Location = New System.Drawing.Point(695, 175)
        Me.sch1_L.Name = "sch1_L"
        Me.sch1_L.Size = New System.Drawing.Size(16, 16)
        Me.sch1_L.TabIndex = 749
        Me.sch1_L.TabStop = False
        Me.sch1_L.Visible = False
        '
        'PID
        '
        Me.PID.Image = Global.BioGas.My.Resources.Resources.PID_2
        Me.PID.Location = New System.Drawing.Point(-19, 1)
        Me.PID.Name = "PID"
        Me.PID.Size = New System.Drawing.Size(644, 536)
        Me.PID.TabIndex = 810
        Me.PID.TabStop = False
        '
        'Flare2
        '
        Me.Flare2.Image = Global.BioGas.My.Resources.Resources.flare
        Me.Flare2.InitialImage = Nothing
        Me.Flare2.Location = New System.Drawing.Point(467, 87)
        Me.Flare2.Name = "Flare2"
        Me.Flare2.Size = New System.Drawing.Size(27, 71)
        Me.Flare2.TabIndex = 848
        Me.Flare2.TabStop = False
        '
        'Flare3
        '
        Me.Flare3.Image = Global.BioGas.My.Resources.Resources.flare
        Me.Flare3.InitialImage = Nothing
        Me.Flare3.Location = New System.Drawing.Point(545, 87)
        Me.Flare3.Name = "Flare3"
        Me.Flare3.Size = New System.Drawing.Size(27, 71)
        Me.Flare3.TabIndex = 849
        Me.Flare3.TabStop = False
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(6, 144)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(47, 13)
        Me.Label21.TabIndex = 850
        Me.Label21.Text = "Sim PLC"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(774, 549)
        Me.Controls.Add(Me.Label21)
        Me.Controls.Add(Me.Flare3)
        Me.Controls.Add(Me.Flare2)
        Me.Controls.Add(Me.Flare1)
        Me.Controls.Add(Me.CheckBoxSimOn)
        Me.Controls.Add(Me.LabelSPtem)
        Me.Controls.Add(Me.LabelChan5)
        Me.Controls.Add(Me.LabelChan4)
        Me.Controls.Add(Me.LabelChan3)
        Me.Controls.Add(Me.LabelChan2)
        Me.Controls.Add(Me.LabelChan1)
        Me.Controls.Add(Me.LabelSPPos)
        Me.Controls.Add(Me.LabelCH5)
        Me.Controls.Add(Me.LabelCH4)
        Me.Controls.Add(Me.LabelCH3)
        Me.Controls.Add(Me.LabelCH2)
        Me.Controls.Add(Me.LabelCH1)
        Me.Controls.Add(Me.LedCH5)
        Me.Controls.Add(Me.LedCH4)
        Me.Controls.Add(Me.LedCH3)
        Me.Controls.Add(Me.LedCH2)
        Me.Controls.Add(Me.LedCH1)
        Me.Controls.Add(Me.StartUpPressure)
        Me.Controls.Add(Me.CheckBoxSimPos)
        Me.Controls.Add(Me.NumericUpDownSimPos)
        Me.Controls.Add(Me.NumericUpDownSimT)
        Me.Controls.Add(Me.LabelPID)
        Me.Controls.Add(Me.CheckBoxSimTemp)
        Me.Controls.Add(Me.LabelAutoManual)
        Me.Controls.Add(Me.LabelFlow)
        Me.Controls.Add(Me.Valve_Stage1_OFF)
        Me.Controls.Add(Me.Valve_Stage1_ON)
        Me.Controls.Add(Me.Label20)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.Label19)
        Me.Controls.Add(Me.Label18)
        Me.Controls.Add(Me.LabelPos)
        Me.Controls.Add(Me.LabelTemp)
        Me.Controls.Add(Me.LabelPR)
        Me.Controls.Add(Me.CBRange)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.RangeMin)
        Me.Controls.Add(Me.RangeMax)
        Me.Controls.Add(Me.ControlFlapClose_OFF)
        Me.Controls.Add(Me.ControlFlapClose_ON)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.ControlFlapOpen_OFF)
        Me.Controls.Add(Me.ControlFlapOpen_ON)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Valve_Stage3_OFF)
        Me.Controls.Add(Me.Valve_Stage3_ON)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Valve_Stage2_OFF)
        Me.Controls.Add(Me.Valve_Stage2_ON)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Led_HighFlareTemp_OFF)
        Me.Controls.Add(Me.Led_HighFlareTemp_ON)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Led_LowNozPres_OFF)
        Me.Controls.Add(Me.Led_LowNozPres_ON)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Led_HighNozPres_OFF)
        Me.Controls.Add(Me.Led_HighNozPres_ON)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Led_Horn_OFF)
        Me.Controls.Add(Me.Led_Horn_ON)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Led_FlareINOper_OFF)
        Me.Controls.Add(Me.Led_FlareInOper_ON)
        Me.Controls.Add(Me.Led_CommonAlarm_OFF)
        Me.Controls.Add(Me.Led_CommonAlarm_ON)
        Me.Controls.Add(Me.Led_ReleaseFlare_OFF)
        Me.Controls.Add(Me.Led_ReleaseFlare_ON)
        Me.Controls.Add(Me.Led_ESD_OFF)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.Led_ESD_ON)
        Me.Controls.Add(Me.Led_BCU_OFF)
        Me.Controls.Add(Me.Label59)
        Me.Controls.Add(Me.Led_BCU_ON)
        Me.Controls.Add(Me.Position)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Temperature)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Pressure)
        Me.Controls.Add(Me.LabelValue)
        Me.Controls.Add(Me.sch1_R)
        Me.Controls.Add(Me.sch1_C)
        Me.Controls.Add(Me.sch1_L)
        Me.Controls.Add(Me.Bsch1_R)
        Me.Controls.Add(Me.Bsch1_C)
        Me.Controls.Add(Me.Bsch1_L)
        Me.Controls.Add(Me.Label263)
        Me.Controls.Add(Me.FlareInOperation)
        Me.Controls.Add(Me.ReleaseFlare)
        Me.Controls.Add(Me.BCUFault)
        Me.Controls.Add(Me.ESD_LCP)
        Me.Controls.Add(Me.ESD_CUST)
        Me.Controls.Add(Me.ButtonResetLCP)
        Me.Controls.Add(Me.ButtonReset)
        Me.Controls.Add(Me.PID)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Form1"
        Me.Text = "BioGas simulatie "
        CType(Me.Position, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Temperature, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Pressure, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.RangeMin, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.RangeMax, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDownSimT, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDownSimPos, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Flare1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Valve_Stage1_OFF, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Valve_Stage1_ON, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ControlFlapClose_OFF, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ControlFlapClose_ON, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ControlFlapOpen_OFF, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ControlFlapOpen_ON, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Valve_Stage3_OFF, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Valve_Stage3_ON, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Valve_Stage2_OFF, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Valve_Stage2_ON, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Led_HighFlareTemp_OFF, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Led_HighFlareTemp_ON, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Led_LowNozPres_OFF, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Led_LowNozPres_ON, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Led_HighNozPres_OFF, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Led_HighNozPres_ON, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Led_Horn_OFF, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Led_Horn_ON, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Led_FlareINOper_OFF, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Led_FlareInOper_ON, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Led_CommonAlarm_OFF, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Led_CommonAlarm_ON, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Led_ReleaseFlare_OFF, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Led_ReleaseFlare_ON, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Led_ESD_OFF, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Led_ESD_ON, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Led_BCU_OFF, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Led_BCU_ON, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.sch1_R, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.sch1_C, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.sch1_L, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PID, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Flare2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Flare3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents ControlFlapClose_OFF As System.Windows.Forms.PictureBox
    Friend WithEvents ControlFlapClose_ON As System.Windows.Forms.PictureBox
    Friend WithEvents ControlFlapOpen_OFF As System.Windows.Forms.PictureBox
    Friend WithEvents TimerGUI As System.Windows.Forms.Timer
    Friend WithEvents ControlFlapOpen_ON As System.Windows.Forms.PictureBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Valve_Stage3_OFF As System.Windows.Forms.PictureBox
    Friend WithEvents Valve_Stage3_ON As System.Windows.Forms.PictureBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Valve_Stage2_OFF As System.Windows.Forms.PictureBox
    Friend WithEvents Valve_Stage2_ON As System.Windows.Forms.PictureBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Led_HighFlareTemp_OFF As System.Windows.Forms.PictureBox
    Friend WithEvents Led_HighFlareTemp_ON As System.Windows.Forms.PictureBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Led_LowNozPres_OFF As System.Windows.Forms.PictureBox
    Friend WithEvents Led_LowNozPres_ON As System.Windows.Forms.PictureBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Led_HighNozPres_OFF As System.Windows.Forms.PictureBox
    Friend WithEvents Led_HighNozPres_ON As System.Windows.Forms.PictureBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Led_Horn_OFF As System.Windows.Forms.PictureBox
    Friend WithEvents Led_Horn_ON As System.Windows.Forms.PictureBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Led_FlareINOper_OFF As System.Windows.Forms.PictureBox
    Friend WithEvents Led_FlareInOper_ON As System.Windows.Forms.PictureBox
    Friend WithEvents Led_CommonAlarm_OFF As System.Windows.Forms.PictureBox
    Friend WithEvents Led_CommonAlarm_ON As System.Windows.Forms.PictureBox
    Friend WithEvents Led_ReleaseFlare_OFF As System.Windows.Forms.PictureBox
    Friend WithEvents Led_ReleaseFlare_ON As System.Windows.Forms.PictureBox
    Friend WithEvents Led_ESD_OFF As System.Windows.Forms.PictureBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Led_ESD_ON As System.Windows.Forms.PictureBox
    Friend WithEvents Led_BCU_OFF As System.Windows.Forms.PictureBox
    Friend WithEvents Label59 As System.Windows.Forms.Label
    Friend WithEvents Led_BCU_ON As System.Windows.Forms.PictureBox
    Friend WithEvents Position As System.Windows.Forms.TrackBar
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Temperature As System.Windows.Forms.TrackBar
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents LabelValue As System.Windows.Forms.Label
    Friend WithEvents sch1_R As System.Windows.Forms.PictureBox
    Friend WithEvents sch1_C As System.Windows.Forms.PictureBox
    Friend WithEvents sch1_L As System.Windows.Forms.PictureBox
    Friend WithEvents Bsch1_R As System.Windows.Forms.Label
    Friend WithEvents Bsch1_C As System.Windows.Forms.Label
    Friend WithEvents Bsch1_L As System.Windows.Forms.Label
    Friend WithEvents Label263 As System.Windows.Forms.Label
    Friend WithEvents FlareInOperation As System.Windows.Forms.CheckBox
    Friend WithEvents ReleaseFlare As System.Windows.Forms.CheckBox
    Friend WithEvents BCUFault As System.Windows.Forms.CheckBox
    Friend WithEvents ESD_LCP As System.Windows.Forms.CheckBox
    Friend WithEvents ESD_CUST As System.Windows.Forms.CheckBox
    Friend WithEvents ButtonResetLCP As System.Windows.Forms.Button
    Friend WithEvents ButtonReset As System.Windows.Forms.Button
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents RangeMin As System.Windows.Forms.NumericUpDown
    Friend WithEvents RangeMax As System.Windows.Forms.NumericUpDown
    Friend WithEvents CBRange As System.Windows.Forms.CheckBox
    Friend WithEvents LabelPR As System.Windows.Forms.Label
    Friend WithEvents LabelTemp As System.Windows.Forms.Label
    Friend WithEvents LabelPos As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents PID As System.Windows.Forms.PictureBox
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Valve_Stage1_ON As System.Windows.Forms.PictureBox
    Friend WithEvents Valve_Stage1_OFF As System.Windows.Forms.PictureBox
    Friend WithEvents LabelFlow As System.Windows.Forms.Label
    Friend WithEvents LabelAutoManual As System.Windows.Forms.Label
    Friend WithEvents CheckBoxSimTemp As System.Windows.Forms.CheckBox
    Friend WithEvents LabelPID As System.Windows.Forms.Label
    Friend WithEvents NumericUpDownSimT As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDownSimPos As System.Windows.Forms.NumericUpDown
    Friend WithEvents CheckBoxSimPos As System.Windows.Forms.CheckBox
    Friend WithEvents StartUpPressure As System.Windows.Forms.CheckBox
    Friend WithEvents LedCH1 As System.Windows.Forms.Panel
    Friend WithEvents LedCH2 As System.Windows.Forms.Panel
    Friend WithEvents LedCH3 As System.Windows.Forms.Panel
    Friend WithEvents LedCH4 As System.Windows.Forms.Panel
    Friend WithEvents LedCH5 As System.Windows.Forms.Panel
    Friend WithEvents LabelCH5 As System.Windows.Forms.Label
    Friend WithEvents LabelCH4 As System.Windows.Forms.Label
    Friend WithEvents LabelCH3 As System.Windows.Forms.Label
    Friend WithEvents LabelCH2 As System.Windows.Forms.Label
    Friend WithEvents LabelCH1 As System.Windows.Forms.Label
    Friend WithEvents LabelSPPos As System.Windows.Forms.Label
    Friend WithEvents LabelChan1 As System.Windows.Forms.Label
    Friend WithEvents LabelChan2 As System.Windows.Forms.Label
    Friend WithEvents LabelChan3 As System.Windows.Forms.Label
    Friend WithEvents LabelChan4 As System.Windows.Forms.Label
    Friend WithEvents LabelChan5 As System.Windows.Forms.Label
    Friend WithEvents LabelSPtem As System.Windows.Forms.Label
    Protected WithEvents Pressure As System.Windows.Forms.TrackBar
    Friend WithEvents CheckBoxSimOn As System.Windows.Forms.CheckBox
    Friend WithEvents Flare1 As System.Windows.Forms.PictureBox
    Friend WithEvents Flare2 As System.Windows.Forms.PictureBox
    Friend WithEvents Flare3 As System.Windows.Forms.PictureBox
    Friend WithEvents Label21 As System.Windows.Forms.Label

End Class
