﻿Public Class Form1
    Private WithEvents S7ProSim As New S7PROSIMLib.S7ProSim
    Private Li As Boolean = False
    Private Ce As Boolean = False
    Private Ri As Boolean = False
    Private Wa As Boolean = False
    Private Dw As Boolean = False
    Private Up As Boolean = False

    Private Sub Form1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        S7ProSim.Connect()
        S7ProSim.SetScanMode(1)
        UpdateGUI()
        'Init
        SimKlock = False
        Sw1(2) 'out  
    End Sub

    Private Sub UpdateGUI()
        S7ProSim.WriteInputPoint(0, 2, Not ESD_CUST.Checked)
        S7ProSim.WriteInputPoint(0, 3, Not ESD_LCP.Checked)
        S7ProSim.WriteInputPoint(0, 4, BCUFault.Checked)
        S7ProSim.WriteInputPoint(0, 7, ReleaseFlare.Checked)
        S7ProSim.WriteInputPoint(1, 0, StartUpPressure.Checked)
        S7ProSim.WriteInputPoint(1, 1, FlareInOperation.Checked)

        pDataAna(0) = Pressure.Value
        S7ProSim.WriteInputPoint(272, 0, pDataAna(0))
        pDataAna(0) = Temperature.Value
        S7ProSim.WriteInputPoint(276, 0, pDataAna(0))
        pDataAna(0) = Position.Value
        S7ProSim.WriteInputPoint(274, 0, pDataAna(0))

        S7ProSim.ReadOutputPoint(0, 0, S7PROSIMLib.PointDataTypeConstants.S7_Byte, pDataCons(0))
        'Q0.0-7 
        Led_ESD_ON.Visible = IsBitSet(pDataCons(0), 0)
        Led_ESD_OFF.Visible = Not (IsBitSet(pDataCons(0), 0))
        Led_BCU_ON.Visible = IsBitSet(pDataCons(0), 1)
        Led_BCU_OFF.Visible = Not (IsBitSet(pDataCons(0), 1))
        Led_ReleaseFlare_ON.Visible = IsBitSet(pDataCons(0), 2)
        Led_ReleaseFlare_OFF.Visible = Not (IsBitSet(pDataCons(0), 2))
        Led_CommonAlarm_ON.Visible = IsBitSet(pDataCons(0), 3)
        Led_CommonAlarm_OFF.Visible = Not (IsBitSet(pDataCons(0), 3))
        Led_FlareInOper_ON.Visible = IsBitSet(pDataCons(0), 4)
        Led_FlareInOper_OFF.Visible = Not (IsBitSet(pDataCons(0), 4))
        Led_Horn_ON.Visible = IsBitSet(pDataCons(0), 5)
        Led_Horn_OFF.Visible = Not (IsBitSet(pDataCons(0), 5))
        Led_HighNozPres_ON.Visible = IsBitSet(pDataCons(0), 6)
        Led_HighNozPres_OFF.Visible = Not (IsBitSet(pDataCons(0), 6))
        Led_LowNozPres_ON.Visible = IsBitSet(pDataCons(0), 7)
        Led_LowNozPres_OFF.Visible = Not (IsBitSet(pDataCons(0), 7))

        'flare in operetion
        Valve_Stage1_ON.Visible = IsBitSet(pDataCons(0), 4)
        Valve_Stage1_OFF.Visible = Not (IsBitSet(pDataCons(0), 4))
        Flare1.Visible = IsBitSet(pDataCons(0), 4)


        S7ProSim.ReadOutputPoint(1, 0, S7PROSIMLib.PointDataTypeConstants.S7_Byte, pDataCons(0))
        Led_HighFlareTemp_ON.Visible = IsBitSet(pDataCons(0), 0)
        Led_HighFlareTemp_OFF.Visible = Not (IsBitSet(pDataCons(0), 0))
        Valve_Stage2_ON.Visible = IsBitSet(pDataCons(0), 1)
        Valve_Stage2_OFF.Visible = Not (IsBitSet(pDataCons(0), 1))
        Flare2.Visible = IsBitSet(pDataCons(0), 1)
        Valve_Stage3_ON.Visible = IsBitSet(pDataCons(0), 2)
        Valve_Stage3_OFF.Visible = Not (IsBitSet(pDataCons(0), 2))
        Flare3.Visible = IsBitSet(pDataCons(0), 2)
        ControlFlapOpen_ON.Visible = IsBitSet(pDataCons(0), 4)
        ControlFlapOpen_OFF.Visible = Not (IsBitSet(pDataCons(0), 4))
        ControlFlapClose_ON.Visible = IsBitSet(pDataCons(0), 3)
        ControlFlapClose_OFF.Visible = Not (IsBitSet(pDataCons(0), 3))

        If CheckBoxSimPos.Checked Then
            'Close Flap
            If IsBitSet(pDataCons(0), 3) Then
                Position.Value = Position.Value - NumericUpDownSimPos.Value
            End If
            'Open Flap
            If IsBitSet(pDataCons(0), 4) Then
                Position.Value = Position.Value + NumericUpDownSimPos.Value
            End If
        End If

        'proces simulation
        S7ProSim.WriteDataBlockValue(1020, 0, 7, CheckBoxSimOn.Checked)
        If CheckBoxSimTemp.Checked And simT Then
            'Close Flap
            If IsBitSet(pDataCons(0), 3) Then
                Temperature.Value = Temperature.Value - NumericUpDownSimT.Value
            End If
            'Open Flap
            If IsBitSet(pDataCons(0), 4) Then
                Temperature.Value = Temperature.Value + NumericUpDownSimT.Value
            End If

        End If

        S7ProSim.ReadDataBlockValue(1011, 0, 0, 4, pDataI)
        LabelPR.Text = String.Format("{0,10:N2} mbar", CDbl(BitConverter.ToSingle(BitConverter.GetBytes(pDataI), 0)))

        S7ProSim.ReadDataBlockValue(1011, 4, 0, 4, pDataI)
        LabelTemp.Text = String.Format("{0,10:N2} °C", CDbl(BitConverter.ToSingle(BitConverter.GetBytes(pDataI), 0)))

        S7ProSim.ReadDataBlockValue(1011, 8, 0, 4, pDataI)
        LabelPos.Text = String.Format("{0,10:N2} °", CDbl(BitConverter.ToSingle(BitConverter.GetBytes(pDataI), 0)))

        S7ProSim.ReadDataBlockValue(1011, 12, 0, 4, pDataI)
        LabelFlow.Text = String.Format("Flow={0,10:N2} m3/h", CDbl(BitConverter.ToSingle(BitConverter.GetBytes(pDataI), 0)))


        S7ProSim.ReadDataBlockValue(1007, 4, 0, 3, pDataShort)
        If pDataShort = 0 Then
            LabelAutoManual.Text = String.Format("Mode - Manual")
        Else
            LabelAutoManual.Text = String.Format("Mode - Auto")
        End If

        S7ProSim.ReadDataBlockValue(1020, 0, 0, 2, pDataRun)
        If IsBitSet(pDataRun, 0) Then
            LedCH1.BackColor = Color.Lime
            LabelChan1.Text = "Temperatura"
        Else
            LedCH1.BackColor = Color.DarkGreen
            LabelChan1.Text = "Pressure"
        End If
        If IsBitSet(pDataRun, 1) Then
            LedCH2.BackColor = Color.Lime
            LabelChan2.Text = "AirLack"
        Else
            LedCH2.BackColor = Color.DarkGreen
            LabelChan2.Text = "NO override"
        End If
        If IsBitSet(pDataRun, 2) Then
            LedCH3.BackColor = Color.Lime
            LabelChan3.Text = "TSH"
        Else
            LedCH3.BackColor = Color.DarkGreen
            LabelChan3.Text = "NO override"
        End If
        If IsBitSet(pDataRun, 3) Then
            LedCH4.BackColor = Color.Lime
            LabelChan4.Text = "Ignition"
        Else
            LedCH4.BackColor = Color.DarkGreen
            LabelChan4.Text = "NO override"
        End If
        If IsBitSet(pDataRun, 4) Then
            LedCH5.BackColor = Color.Lime
            LabelChan5.Text = "Automatic"
        Else
            LedCH5.BackColor = Color.DarkGreen
            LabelChan5.Text = "Manual"
        End If

        If (IsBitSet(pDataRun, 0)) And (Not (IsBitSet(pDataRun, 1))) And (Not (IsBitSet(pDataRun, 2))) And (Not (IsBitSet(pDataRun, 3))) And (IsBitSet(pDataRun, 4)) Then
            simT = True
        Else
            simT = False
        End If
        '--------------------------
        'S7ProSim.ReadDataBlockValue(1011, 20, 0, 4, pDataI)
        'LabelPID.Text = String.Format("SPpid={0,10:N2}", CDbl(BitConverter.ToSingle(BitConverter.GetBytes(pDataI), 0)))

        S7ProSim.ReadDataBlockValue(1020, 2, 0, 4, pDataI)
        LabelCH1.Text = String.Format("Ch1 ={0,10:N2}", CDbl(BitConverter.ToSingle(BitConverter.GetBytes(pDataI), 0)))
        S7ProSim.ReadDataBlockValue(1020, 6, 0, 4, pDataI)
        LabelCH2.Text = String.Format("Ch2 ={0,10:N2}", CDbl(BitConverter.ToSingle(BitConverter.GetBytes(pDataI), 0)))
        S7ProSim.ReadDataBlockValue(1020, 10, 0, 4, pDataI)
        LabelCH3.Text = String.Format("Ch3 ={0,10:N2}", CDbl(BitConverter.ToSingle(BitConverter.GetBytes(pDataI), 0)))
        S7ProSim.ReadDataBlockValue(1020, 14, 0, 4, pDataI)
        LabelCH4.Text = String.Format("Ch4 ={0,10:N2}", CDbl(BitConverter.ToSingle(BitConverter.GetBytes(pDataI), 0)))
        S7ProSim.ReadDataBlockValue(1020, 18, 0, 4, pDataI)
        LabelCH5.Text = String.Format("Ch5 ={0,10:N2}", CDbl(BitConverter.ToSingle(BitConverter.GetBytes(pDataI), 0)))


        S7ProSim.ReadDataBlockValue(1020, 22, 0, 4, pDataI)
        LabelPID.Text = String.Format("Reg.temp. ={0,10:N2}", CDbl(BitConverter.ToSingle(BitConverter.GetBytes(pDataI), 0)))
        S7ProSim.ReadDataBlockValue(1020, 26, 0, 4, pDataI)
        LabelSPPos.Text = String.Format("SP pos. ={0,10:N2}", CDbl(BitConverter.ToSingle(BitConverter.GetBytes(pDataI), 0)))
        S7ProSim.ReadDataBlockValue(1020, 30, 0, 4, pDataI)
        LabelSPtem.Text = String.Format("SP temp. ={0,10:N2}", CDbl(BitConverter.ToSingle(BitConverter.GetBytes(pDataI), 0)))



    End Sub
    Sub SwChoice(ByVal Choice As Byte, ByVal num As Byte)
        Select Case Choice
            Case 1
                Li = True
                Ce = False
                Ri = False
                Wa = False
            Case 2
                Li = False
                Ce = True
                Ri = False
                Wa = False
            Case 3
                Li = False
                Ce = False
                Ri = True
                Wa = False
            Case 4
                Li = False
                Ce = False
                Ri = False
                Wa = True
        End Select
        Sw(num) = Choice
    End Sub
    Sub Sw1(ByVal Choice As Byte)
        SwChoice(Choice, 2)
        S7ProSim.WriteInputPoint(0, 6, Li)
        S7ProSim.WriteInputPoint(0, 5, Ri)
        sch1_L.Visible = Li
        sch1_C.Visible = Ce
        sch1_R.Visible = Ri
    End Sub
  
    Private Sub ButtonresetLCP_MouseDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles ButtonResetLCP.MouseDown
        S7ProSim.WriteInputPoint(0, 1, True)
    End Sub

    Private Sub ButtonresetLCP_MouseUp(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles ButtonResetLCP.MouseUp
        S7ProSim.WriteInputPoint(0, 1, False)
    End Sub

    Private Sub Timer2_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TimerGUI.Tick
        UpdateGUI()
    End Sub

    Private Sub Bsch1_L_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Bsch1_L.Click
        Sw1(1)
    End Sub

    Private Sub Bsch1_C_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Bsch1_C.Click
        Sw1(2)
    End Sub

    Private Sub Bsch1_R_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Bsch1_R.Click
        Sw1(3)
    End Sub

    Private Sub ButtonReset_MouseDown_1(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles ButtonReset.MouseDown
        S7ProSim.WriteInputPoint(0, 0, True)
    End Sub

    Private Sub ButtonReset_MouseUp(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles ButtonReset.MouseUp
        S7ProSim.WriteInputPoint(0, 0, False)
    End Sub

    Private Sub CBRange_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CBRange.CheckedChanged
        If CBRange.Checked Then
            RangeMax.Value = 32700
            RangeMin.Value = -6000
            CBRange.Text = "Fault range"
        Else
            RangeMax.Value = 27648
            RangeMin.Value = 0
            CBRange.Text = "Normal range"
        End If
        Pressure.Maximum = RangeMax.Value
        Pressure.Minimum = RangeMin.Value
        Temperature.Maximum = RangeMax.Value
        Temperature.Minimum = RangeMin.Value
        Position.Maximum = RangeMax.Value
        Position.Minimum = RangeMin.Value
    End Sub

 End Class
